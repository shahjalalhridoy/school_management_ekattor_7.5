<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	$status = array(
	    'status' => array(
	        'type' => 'int',
	        'default' => 0,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('users', $status);

	$smtp_crypto = array(
	    'smtp_crypto' => array(
	        'type' => 'varchar',
	        'constraint' => 255,
	        'default' => 0,
	        'collation' => 'utf8_unicode_ci'
	    )
	);
	$CI->dbforge->add_column('smtp_settings', $smtp_crypto);


	$CI->db->where('unique_identifier', 'online_admission');
	$row = $CI->db->get('menus');
	if($row->num_rows() <= 0){
		$CI->db->insert('menus', array('displayed_name' => 'online_admission', 'route_name' => 'online_admission', 'parent' => 0, 'icon' => 'dripicons-graduation', 'status' => 1, 'superadmin_access' => 1, 'admin_access' => 1, 'teacher_access' => 0, 'parent_access' => 0, 'student_access' => 0, 'accountant_access' => 0, 'librarian_access' => 0, 'sort_order' => 9, 'is_addon' => 0, 'unique_identifier' => 'online_admission'));
	}

	//update data in settings table
	$settings_data = array( 'version' => '7.4' );
	$CI->db->update('settings', $settings_data);
?>
